# Starlink-Intersatellite-Link
This is a project is based on Elon Musk's Starlink project and is part of OOPS 2-1 coursework .


To run the code go to src folder then execute the Driver.java by

javac Driver.java 

java Driver

