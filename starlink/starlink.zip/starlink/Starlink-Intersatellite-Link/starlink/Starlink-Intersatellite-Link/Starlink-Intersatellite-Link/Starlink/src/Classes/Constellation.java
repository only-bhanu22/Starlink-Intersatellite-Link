package Classes;

public abstract class Constellation {
    Constellation(){
        // System.out.println("This is the constellation which contains all the starlink satellites");
    }
}
