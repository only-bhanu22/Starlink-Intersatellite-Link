package Classes;

public interface CommunicationInterface {
    public int sendMessage() ;
}
