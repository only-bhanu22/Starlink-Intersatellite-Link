package Colors;

public class Colors {

    public static final String RESET = "\033[0m";
    public static final String RED = "\033[0;31m";
    public static final String GREEN = "\033[0;32m"; 
    public static final String PURPLE = "\033[1;95m";
    public static final String YELLOW = "\u001B[33m";
    public static final String CYAN = "\u001B[36m";
}
