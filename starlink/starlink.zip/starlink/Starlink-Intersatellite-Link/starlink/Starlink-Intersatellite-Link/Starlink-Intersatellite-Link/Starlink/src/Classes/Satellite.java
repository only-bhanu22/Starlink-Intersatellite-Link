package Classes;

public abstract class Satellite extends Constellation implements CommunicationInterface {
    Satellite(){
        // System.out.println("This is the satellite a small part of constellation which contains one GSO-Satellite and five LEO-Satellite");
    }
}

